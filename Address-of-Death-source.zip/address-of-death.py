from __future__ import annotations
import sys
import re
import time
import random
import requests
import os
import csv
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup
import docx
import pypdf

from PyQt6.QtCore import Qt, QThread, QTimer, pyqtSignal as Signal
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QPalette, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QLineEdit, QPushButton, QTextEdit, QSpinBox, QCheckBox,
    QFileDialog, QMessageBox, QTabWidget, QSplashScreen,
    QSizePolicy, QScrollArea, QFrame
)

# =============================================================================
# CONFIGURATION & UTILS
# =============================================================================
EMAIL_REGEX = re.compile(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+')

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/115.0.1901.203 Safari/537.36"
]

def apply_dark_theme(app):
    app.setStyle("Fusion")
    dark_palette = QPalette()
    dark_palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
    dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
    dark_palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
    dark_palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
    dark_palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
    dark_palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
    app.setPalette(dark_palette)

# =============================================================================
# ORIGINAL SPLASH SCREEN
# =============================================================================
APP_NAME = "Address of Death"
ORG_NAME = "Death's Head Software"

def create_splash():
    try:
        splash_path = Path(__file__).parent / "splash.png"
        
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                 "        ___________       ",
                 "       /           \\     ",
                 "      |  O       O  |    ",
                 "      |      ^      |    ",
                 "      |   \\_____/   |    ",
                 "       \\_         _/     ",
                 "         |_______|       ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): 
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error: ", e)
        return None

# =============================================================================
# WEB SCRAPER WORKER
# =============================================================================
class ScraperWorker(QThread):
    progress = Signal(str)
    found_email = Signal(str)
    finished = Signal(list)
    error = Signal(str)

    def __init__(self, url, delay_range=(1, 3), use_ua_rotation=True, max_pages=5):
        super().__init__()
        self.url = url
        self.delay_range = delay_range
        self.use_ua_rotation = use_ua_rotation
        self.max_pages = max_pages
        self._emails = set()
        self._stop_flag = False

    def stop(self):
        self._stop_flag = True

    def run(self):
        session = requests.Session()
        try:
            self._scrape_page(session, self.url, depth=0)
        except Exception as e:
            self.error.emit(str(e))
        finally:
            self.finished.emit(list(self._emails))

    def _scrape_page(self, session, url, depth):
        if self._stop_flag or depth >= self.max_pages:
            return

        self.progress.emit(f"Scanning: {url} (Depth: {depth})")
        headers = {"User-Agent": random.choice(USER_AGENTS) if self.use_ua_rotation else USER_AGENTS[0]}
        
        try:
            resp = session.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            text = soup.get_text()
            
            matches = EMAIL_REGEX.findall(text)
            for email in matches:
                if email not in self._emails:
                    self._emails.add(email)
                    self.found_email.emit(email)

            links = [a.get("href") for a in soup.find_all("a", href=True)]
            for link in links:
                if self._stop_flag: break
                full_link = requests.compat.urljoin(url, link)
                if not full_link.startswith(("http", "https")): continue
                if "javascript" in full_link or "#" in full_link: continue
                self._scrape_page(session, full_link, depth + 1)

            time.sleep(random.uniform(*self.delay_range))
        except Exception as e:
            self.progress.emit(f"Error on {url}: {str(e)}")

# =============================================================================
# SCROLLABLE HELPER
# =============================================================================
def create_scrollable_content(widget: QWidget) -> QScrollArea:
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setWidget(widget)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    return scroll

# =============================================================================
# FILE HARVESTER TAB
# =============================================================================
class FileHarvesterTab(QWidget):
    emails_found = Signal(list)

    def __init__(self):
        super().__init__()
        self.folder_path = ""
        self.found_emails: set[str] = set()

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        self.folder_label = QLabel("Select Folder containing .txt, .doc, .docx, .pdf files:")
        self.folder_btn = QPushButton("📂 Choose Folder")
        self.folder_btn.clicked.connect(self.select_folder)

        self.status_label = QLabel("Ready")
        self.status_label.setWordWrap(True)

        self.run_btn = QPushButton("🔍 Extract Emails")
        self.run_btn.clicked.connect(self.run_harvest)
        self.run_btn.setEnabled(False)

        self.results = QTextEdit()
        self.results.setReadOnly(True)
        self.results.setMinimumHeight(320)

        export_layout = QHBoxLayout()
        self.export_csv_btn = QPushButton("📤 Export CSV")
        self.export_csv_btn.clicked.connect(self.export_csv)
        self.export_csv_btn.setEnabled(False)
        self.export_txt_btn = QPushButton("📄 Export TXT")
        self.export_txt_btn.clicked.connect(self.export_txt)
        self.export_txt_btn.setEnabled(False)
        export_layout.addWidget(self.export_csv_btn)
        export_layout.addWidget(self.export_txt_btn)
        export_layout.addStretch()

        layout.addWidget(self.folder_label)
        layout.addWidget(self.folder_btn)
        layout.addWidget(self.status_label)
        layout.addWidget(self.run_btn)
        layout.addWidget(self.results, stretch=1)
        layout.addLayout(export_layout)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(create_scrollable_content(content))

    # ... (rest of FileHarvesterTab remains the same)
    def select_folder(self):
        dialog = QFileDialog(self)
        dialog.setFileMode(QFileDialog.FileMode.Directory)
        if dialog.exec():
            self.folder_path = dialog.selectedFiles()[0]
            self.status_label.setText(f"Selected: {self.folder_path}")
            self.run_btn.setEnabled(True)

    def run_harvest(self):
        self.found_emails.clear()
        self.results.clear()
        self.status_label.setText("Processing...")
        self.run_btn.setEnabled(False)
        QTimer.singleShot(50, self._process_files)

    def _process_files(self):
        valid_ext = {".txt", ".doc", ".docx", ".pdf"}
        for root, _, files in os.walk(self.folder_path):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext not in valid_ext: continue
                path = os.path.join(root, file)
                try:
                    text = self._extract_text(path, ext)
                    emails = EMAIL_REGEX.findall(text)
                    self.found_emails.update(emails)
                except Exception as e:
                    self.results.append(f"⚠️ {file}: {str(e)}")

        self.results.setPlainText(f"✅ Found {len(self.found_emails)} unique emails.\n\n" + 
                                  "\n".join(sorted(self.found_emails)))
        self.status_label.setText("Done!")
        self.run_btn.setEnabled(True)
        self.export_csv_btn.setEnabled(True)
        self.export_txt_btn.setEnabled(True)
        self.emails_found.emit(list(self.found_emails))

    def _extract_text(self, path, ext):
        if ext == ".txt":
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        elif ext == ".docx":
            doc = docx.Document(path)
            return "\n".join(p.text for p in doc.paragraphs)
        elif ext == ".pdf":
            reader = pypdf.PdfReader(path)
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        return ""

    def export_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if not path: return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Email", "Source", "Extracted At"])
            for email in sorted(self.found_emails):
                writer.writerow([email, "Local Files", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        QMessageBox.information(self, "Export", f"Saved to {path}")

    def export_txt(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save TXT", "", "Text Files (*.txt)")
        if not path: return
        with open(path, "w", encoding="utf-8") as f:
            for email in sorted(self.found_emails):
                f.write(email + "\n")
        QMessageBox.information(self, "Export", f"Saved to {path}")

# =============================================================================
# WEB SCRAPER TAB - Fixed Export Buttons
# =============================================================================
class WebScraperTab(QWidget):
    def __init__(self):
        super().__init__()
        self.found_emails: set[str] = set()
        self.worker = None

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("https://example.com")
        self.url_input.setMinimumHeight(34)

        settings_layout = QHBoxLayout()
        settings_layout.addWidget(QLabel("Delay:"))
        self.delay_min = QSpinBox()
        self.delay_min.setRange(0, 10)
        self.delay_min.setValue(1)
        self.delay_max = QSpinBox()
        self.delay_max.setRange(0, 15)
        self.delay_max.setValue(3)
        settings_layout.addWidget(self.delay_min)
        settings_layout.addWidget(QLabel("-"))
        settings_layout.addWidget(self.delay_max)
        self.ua_rot = QCheckBox("Rotate User-Agents")
        self.ua_rot.setChecked(True)
        settings_layout.addWidget(self.ua_rot)
        settings_layout.addWidget(QLabel("Max Depth:"))
        self.max_depth = QSpinBox()
        self.max_depth.setRange(1, 10)
        self.max_depth.setValue(3)
        settings_layout.addWidget(self.max_depth)
        settings_layout.addStretch()

        self.status_label = QLabel("Idle")
        self.status_label.setWordWrap(True)

        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("🌐 Start Scraping")
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.stop_btn)
        btn_layout.addStretch()

        self.results = QTextEdit()
        self.results.setReadOnly(True)
        self.results.setMinimumHeight(320)

        export_layout = QHBoxLayout()
        self.export_csv_btn = QPushButton("📤 Export CSV")
        self.export_csv_btn.clicked.connect(self.export_csv)
        self.export_csv_btn.setEnabled(False)
        self.export_txt_btn = QPushButton("📄 Export TXT")
        self.export_txt_btn.clicked.connect(self.export_txt)
        self.export_txt_btn.setEnabled(False)
        export_layout.addWidget(self.export_csv_btn)
        export_layout.addWidget(self.export_txt_btn)
        export_layout.addStretch()

        layout.addWidget(QLabel("Target URL:"))
        layout.addWidget(self.url_input)
        layout.addLayout(settings_layout)
        layout.addWidget(self.status_label)
        layout.addLayout(btn_layout)
        layout.addWidget(self.results, stretch=1)
        layout.addLayout(export_layout)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(create_scrollable_content(content))

        self.start_btn.clicked.connect(self.start_scraper)
        self.stop_btn.clicked.connect(self.stop_scraper)

    def start_scraper(self):
        url = self.url_input.text().strip()
        if not url:
            QMessageBox.warning(self, "Input Error", "Please enter a valid URL")
            return
        self.found_emails.clear()
        self.results.clear()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.export_csv_btn.setEnabled(False)
        self.export_txt_btn.setEnabled(False)
        self.status_label.setText("Scraping...")

        self.worker = ScraperWorker(
            url=url,
            delay_range=(self.delay_min.value(), self.delay_max.value()),
            use_ua_rotation=self.ua_rot.isChecked(),
            max_pages=self.max_depth.value()
        )
        self.worker.progress.connect(self.status_label.setText)
        self.worker.found_email.connect(self._add_email)
        self.worker.error.connect(lambda msg: self.results.append(f"❌ {msg}"))
        self.worker.finished.connect(self._scrape_done)
        self.worker.start()

    def _add_email(self, email):
        if email not in self.found_emails:
            self.found_emails.add(email)
            self.results.append(email)

    def stop_scraper(self):
        if self.worker:
            self.worker.stop()
            self.stop_btn.setEnabled(False)
            self.status_label.setText("Stopped")

    def _scrape_done(self, emails):
        self.found_emails.update(emails)
        self.results.setPlainText("\n".join(sorted(self.found_emails)) if self.found_emails else "No emails found.")
        
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.export_csv_btn.setEnabled(True)
        self.export_txt_btn.setEnabled(True)
        self.status_label.setText(f"✅ Finished. {len(self.found_emails)} emails found.")

    def export_csv(self):
        if not self.found_emails:
            QMessageBox.warning(self, "Nothing to Export", "No emails to export.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if not path: return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Email", "Source", "Extracted At"])
            for email in sorted(self.found_emails):
                writer.writerow([email, self.url_input.text() or "Web Scrape", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        QMessageBox.information(self, "Export", f"Saved to {path}")

    def export_txt(self):
        if not self.found_emails:
            QMessageBox.warning(self, "Nothing to Export", "No emails to export.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save TXT", "", "Text Files (*.txt)")
        if not path: return
        with open(path, "w", encoding="utf-8") as f:
            for email in sorted(self.found_emails):
                f.write(email + "\n")
        QMessageBox.information(self, "Export", f"Saved to {path}")

# =============================================================================
# MAIN WINDOW
# =============================================================================
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Address of Death")
        self.resize(1000, 720)
        self.setMinimumSize(880, 620)

        self.tabs = QTabWidget()
        self.tabs.addTab(WebScraperTab(), "🌐 Web Scraper")
        self.tabs.addTab(FileHarvesterTab(), "📁 File Harvester")
        self.setCentralWidget(self.tabs)

# =============================================================================
# MAIN EXECUTION
# =============================================================================
def main():
    app = QApplication(sys.argv)
    apply_dark_theme(app)
    
    icon_path = Path(__file__).parent / "icon.ico"
    if icon_path.exists():
        app_icon = QIcon(str(icon_path))
        app.setWindowIcon(app_icon)

    splash = create_splash()
    
    if splash:
        splash.show()
        for msg in ["Starting...", "Initializing...", "Loading...", "Almost Ready!"]:
            splash.showMessage("\n\n\n\n\n\n\n" + msg, 
                               Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, 
                               QColor(255, 255, 255))
            app.processEvents()
            time.sleep(0.5)
            
        main_window = MainWindow()
        main_window.show()
        splash.finish(main_window)
    else:
        main_window = MainWindow()
        main_window.show()
        
    sys.exit(app.exec())

if __name__ == '__main__':
    main()